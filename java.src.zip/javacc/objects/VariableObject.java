package javacc.objects;

public class VariableObject {
	
	private String type;
	private String name;
	private String operator = "";
	private String initValue = "";
	
	public String getInitValue() {
  	return initValue;
  }

	public void setInitValue(String initValue) {
  	this.initValue = initValue;
  }

	public String getOperator() {
  	return operator;
  }

	public void setOperator(String operator) {
  	this.operator = operator;
  }

	public VariableObject(String name) {
	  super();
	  this.name = name;
  }

	public String getName() {
  	return name;
  }

	public void setName(String name) {
  	this.name = name;
  }

	public String getType() {
  	return type;
  }

	public void setType(String type) {
  	this.type = type;
  }
	
	public String toString() {
		return "type=" + type + "/name=" + name;
	}

}
